package dev.w40k;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.Mirror;
import net.minecraft.world.level.block.Rotation;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.DirectionProperty;
import net.minecraft.world.level.block.state.properties.IntegerProperty;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;

/**
 * One block (tile) of a multi-block model. PART = (y * D + z) * W + x in the unrotated model frame
 * (bow = north, x = east, z = south). Part 0 is the master: it is the placement block and the only one that drops the item.
 */
public class BigUnitBlock extends Block {
    public static final DirectionProperty FACING = BlockStateProperties.HORIZONTAL_FACING;
    public final IntegerProperty part;
    public final int w, d, h;

    private static final ThreadLocal<int[]> PENDING = new ThreadLocal<>();
    private static final ThreadLocal<IntegerProperty> PART_HOLDER = new ThreadLocal<>();

    private static Properties init(Properties properties, int w, int d, int h) {
        PENDING.set(new int[]{w, d, h});
        return properties;
    }

    public BigUnitBlock(Properties properties, int w, int d, int h) {
        super(init(properties, w, d, h)); // the state definition is built inside super(), so the size travels via ThreadLocal
        this.w = w;
        this.d = d;
        this.h = h;
        this.part = PART_HOLDER.get();
        PENDING.remove();
        PART_HOLDER.remove();
        this.registerDefaultState(this.stateDefinition.any().setValue(FACING, Direction.NORTH).setValue(this.part, 0));
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        int[] size = PENDING.get();
        IntegerProperty p = IntegerProperty.create("part", 0, size[0] * size[1] * size[2] - 1);
        PART_HOLDER.set(p);
        builder.add(FACING, p);
    }

    /** Rotates a model-frame tile offset (x east, z south) clockwise by the facing. */
    public static BlockPos rotate(Direction facing, int x, int z) {
        int k = switch (facing) {
            case EAST -> 1;
            case SOUTH -> 2;
            case WEST -> 3;
            default -> 0;
        };
        int rx = x, rz = z;
        for (int i = 0; i < k; i++) {
            int nx = -rz;
            int nz = rx;
            rx = nx;
            rz = nz;
        }
        return new BlockPos(rx, 0, rz);
    }

    /** World position of the tile with the given index, given the master position. */
    public BlockPos tilePos(BlockPos master, Direction facing, int index) {
        int tx = index % w;
        int tz = (index / w) % d;
        int ty = index / (w * d);
        BlockPos r = rotate(facing, tx, tz);
        return master.offset(r.getX(), ty, r.getZ());
    }

    public BlockPos masterOf(BlockPos pos, BlockState state) {
        int index = state.getValue(part);
        Direction f = state.getValue(FACING);
        int tx = index % w;
        int tz = (index / w) % d;
        int ty = index / (w * d);
        BlockPos r = rotate(f, tx, tz);
        return pos.offset(-r.getX(), -ty, -r.getZ());
    }

    @Override
    public void playerWillDestroy(Level level, BlockPos pos, BlockState state, Player player) {
        if (!level.isClientSide && player.isCreative()) {
            removeOthers(level, pos, state, false);
        }
        super.playerWillDestroy(level, pos, state, player);
    }

    @Override
    public void onRemove(BlockState state, Level level, BlockPos pos, BlockState newState, boolean moving) {
        if (!state.is(newState.getBlock()) && !level.isClientSide) {
            removeOthers(level, pos, state, true);
        }
        super.onRemove(state, level, pos, newState, moving);
    }

    private void removeOthers(Level level, BlockPos pos, BlockState state, boolean dropMaster) {
        BlockPos master = masterOf(pos, state);
        Direction f = state.getValue(FACING);
        int self = state.getValue(part);
        for (int i = w * d * h - 1; i >= 0; i--) {
            if (i == self) {
                continue;
            }
            BlockPos p = tilePos(master, f, i);
            BlockState other = level.getBlockState(p);
            if (other.getBlock() != this || other.getValue(part) != i || other.getValue(FACING) != f) {
                continue;
            }
            if (i == 0 && dropMaster && self != 0) {
                level.destroyBlock(p, true);
            } else {
                level.setBlock(p, Blocks.AIR.defaultBlockState(), 35);
            }
        }
    }

    @Override
    public BlockState rotate(BlockState state, Rotation rotation) {
        return state; // multi-block models never rotate with structures
    }

    @Override
    public BlockState mirror(BlockState state, Mirror mirror) {
        return state;
    }

    @Override
    public VoxelShape getCollisionShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
        return Shapes.empty();
    }

    @Override
    public VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
        return Shapes.block();
    }
}
