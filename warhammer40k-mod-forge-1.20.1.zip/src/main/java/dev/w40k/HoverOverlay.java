package dev.w40k;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.locale.Language;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderGuiOverlayEvent;
import net.minecraftforge.client.gui.overlay.VanillaGuiOverlay;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.registries.ForgeRegistries;

/** Shows the name, role and basic profile of the miniature under the crosshair. */
@Mod.EventBusSubscriber(modid = W40kMod.MODID, value = Dist.CLIENT)
public final class HoverOverlay {
    private HoverOverlay() {}

    @SubscribeEvent
    public static void onOverlay(RenderGuiOverlayEvent.Post event) {
        if (event.getOverlay() != VanillaGuiOverlay.CROSSHAIR.type()) {
            return;
        }
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || mc.options.hideGui || mc.screen != null) {
            return;
        }
        HitResult hit = mc.hitResult;
        if (!(hit instanceof BlockHitResult bhr) || hit.getType() != HitResult.Type.BLOCK) {
            return;
        }
        BlockState state = mc.level.getBlockState(bhr.getBlockPos());
        ResourceLocation key = ForgeRegistries.BLOCKS.getKey(state.getBlock());
        if (key == null || !key.getNamespace().equals(W40kMod.MODID)) {
            return;
        }
        String id = key.getPath();
        List<Component> lines = new ArrayList<>();
        lines.add(state.getBlock().getName().copy().withStyle(s -> s.withBold(true).withColor(0xFFD76A)));
        Language lang = Language.getInstance();
        String role = "unitrole." + W40kMod.MODID + "." + id;
        String info = "unitinfo." + W40kMod.MODID + "." + id;
        if (lang.has(role)) {
            lines.add(Component.translatable(role).withStyle(s -> s.withColor(0xB0B0B0)));
        }
        if (lang.has(info)) {
            lines.add(Component.translatable(info).withStyle(s -> s.withColor(0xFFFFFF)));
        }
        GuiGraphics g = event.getGuiGraphics();
        Font font = mc.font;
        int width = 0;
        for (Component c : lines) {
            width = Math.max(width, font.width(c));
        }
        int x = event.getWindow().getGuiScaledWidth() / 2 - width / 2;
        int y = event.getWindow().getGuiScaledHeight() / 2 + 14;
        int height = lines.size() * 11;
        g.fill(x - 4, y - 3, x + width + 4, y + height, 0xAA000000);
        for (int i = 0; i < lines.size(); i++) {
            g.drawString(font, lines.get(i), x, y + i * 11, 0xFFFFFF, true);
        }
    }
}
