package dev.w40k;

import java.util.List;
import javax.annotation.Nullable;
import net.minecraft.ChatFormatting;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;

/** Right-click: roll one D6 per item in the stack. Sneak + right-click: 2D6. Right-click a block: cycle the success target. */
public class D6DiceItem extends Item {
    public D6DiceItem(Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (!level.isClientSide) {
            boolean two = player.isShiftKeyDown();
            int count = two ? 2 : stack.getCount();
            int[] r = new int[count];
            int sum = 0;
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < count; i++) {
                r[i] = level.random.nextInt(6) + 1;
                sum += r[i];
                if (i > 0) {
                    sb.append(", ");
                }
                sb.append(r[i]);
            }
            MutableComponent msg = two
                    ? Component.translatable("msg." + W40kMod.MODID + ".d6.header2", player.getDisplayName())
                    : Component.translatable("msg." + W40kMod.MODID + ".d6.header", player.getDisplayName(), count);
            msg.withStyle(ChatFormatting.GOLD);
            msg.append(Component.literal("\n"));
            msg.append(Component.translatable("msg." + W40kMod.MODID + ".d6.result", sb.toString()).withStyle(ChatFormatting.WHITE));
            msg.append(Component.literal("\n"));
            msg.append(Component.translatable("msg." + W40kMod.MODID + ".d6.sum", sum).withStyle(ChatFormatting.YELLOW));
            int target = stack.hasTag() ? stack.getTag().getInt("target") : 0;
            if (target >= 2 && !two) {
                int ok = 0;
                for (int v : r) {
                    if (v >= target) {
                        ok++;
                    }
                }
                msg.append(Component.literal("\n"));
                msg.append(Component.translatable("msg." + W40kMod.MODID + ".d6.success", target, ok, count).withStyle(ChatFormatting.GREEN));
            }
            for (Player p : level.players()) {
                if (p.distanceToSqr(player) <= 64.0D * 64.0D && p instanceof ServerPlayer sp) {
                    sp.sendSystemMessage(msg);
                }
            }
            player.getCooldowns().addCooldown(this, 10);
        }
        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide);
    }

    @Override
    public InteractionResult useOn(UseOnContext context) {
        Player player = context.getPlayer();
        if (player == null) {
            return InteractionResult.PASS;
        }
        if (!context.getLevel().isClientSide) {
            CompoundTag tag = context.getItemInHand().getOrCreateTag();
            int t = tag.getInt("target") + 1;
            if (t > 6) {
                t = 0;
            } else if (t < 2) {
                t = 2;
            }
            tag.putInt("target", t);
            Component m = t == 0
                    ? Component.translatable("msg." + W40kMod.MODID + ".d6.target.off")
                    : Component.translatable("msg." + W40kMod.MODID + ".d6.target", t + "+");
            player.displayClientMessage(m.copy().withStyle(ChatFormatting.AQUA), true);
        }
        return InteractionResult.sidedSuccess(context.getLevel().isClientSide);
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tooltip, TooltipFlag flag) {
        for (int i = 1; i <= 3; i++) {
            tooltip.add(Component.translatable("tooltip." + W40kMod.MODID + ".d6." + i).withStyle(ChatFormatting.GRAY));
        }
    }
}
