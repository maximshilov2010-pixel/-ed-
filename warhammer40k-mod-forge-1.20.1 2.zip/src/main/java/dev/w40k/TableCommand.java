package dev.w40k;

import com.mojang.brigadier.arguments.IntegerArgumentType;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** /w40ktable [width depth] - flat battlefield under your feet; default 44 x 60 blocks = 44" x 60" (standard Strike Force table). */
@Mod.EventBusSubscriber(modid = W40kMod.MODID)
public final class TableCommand {
    private TableCommand() {}

    @SubscribeEvent
    public static void onRegisterCommands(RegisterCommandsEvent event) {
        event.getDispatcher().register(Commands.literal("w40ktable")
                .requires(src -> src.hasPermission(2))
                .executes(ctx -> build(ctx.getSource(), 44, 60))
                .then(Commands.argument("width", IntegerArgumentType.integer(8, 120))
                        .then(Commands.argument("depth", IntegerArgumentType.integer(8, 120))
                                .executes(ctx -> build(ctx.getSource(),
                                        IntegerArgumentType.getInteger(ctx, "width"),
                                        IntegerArgumentType.getInteger(ctx, "depth"))))));
    }

    private static int build(CommandSourceStack src, int width, int depth) {
        ServerLevel level = src.getLevel();
        Vec3 v = src.getPosition();
        BlockPos origin = BlockPos.containing(v.x, v.y, v.z);
        int floorY = origin.getY() - 1;
        BlockState base = Blocks.GRAY_CONCRETE.defaultBlockState();
        BlockState grid = Blocks.LIGHT_GRAY_CONCRETE.defaultBlockState();
        BlockState edge = Blocks.WHITE_CONCRETE.defaultBlockState();
        BlockState air = Blocks.AIR.defaultBlockState();
        for (int dx = 0; dx < width; dx++) {
            for (int dz = 0; dz < depth; dz++) {
                BlockState state = base;
                if (dx == 0 || dz == 0 || dx == width - 1 || dz == depth - 1) {
                    state = edge;
                } else if (dx % 6 == 0 || dz % 6 == 0) {
                    state = grid;
                }
                BlockPos p = new BlockPos(origin.getX() + dx, floorY, origin.getZ() + dz);
                level.setBlock(p, state, 2);
                for (int h = 1; h <= 6; h++) {
                    level.setBlock(p.above(h), air, 2);
                }
            }
        }
        src.sendSuccess(() -> Component.translatable("msg." + W40kMod.MODID + ".table.done", width, depth), true);
        return 1;
    }
}
